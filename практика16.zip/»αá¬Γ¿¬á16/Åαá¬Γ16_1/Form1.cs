﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практ16_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string st = "";
            string words = textBox1.Text.ToLower();
            if (words == " " || words == "")
            {
                MessageBox.Show("Неверный формат данных");
            }
            else
            {
                if (File.Exists("text.txt"))
                {
                    StreamReader sw = File.OpenText("text.txt");
                    while (!sw.EndOfStream)
                    {
                        st = sw.ReadLine();
                        listBox1.Items.Add(st);
                    }
                    sw.Close();
                }
                else { MessageBox.Show("Файла нет"); }
                int wordsCount = st.ToLower().Split(' ', ',', '.').Count(w => w == words);
                MessageBox.Show($"Слово {words}, было найдено {wordsCount} раз");
            }
           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Clear();
        }
    }
}
