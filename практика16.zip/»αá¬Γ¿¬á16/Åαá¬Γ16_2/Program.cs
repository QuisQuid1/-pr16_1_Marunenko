﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Практ16_2
{
    internal class Program
    {
        static string Swap(string str)
        {
            char[] charArray = str.ToCharArray();
            for (int i = 0; i < charArray.Length; i++)
            {
                if (char.IsLetter(charArray[i]))
                {
                    if (char.IsUpper(charArray[i]))
                    {
                        charArray[i] = char.ToLower(charArray[i]);
                    }
                    else
                    {
                        charArray[i] = char.ToUpper(charArray[i]);
                    }
                }
            }
            return new string(charArray);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку");
            string input = Console.ReadLine();
            int digitCount = 0;
            foreach (var c in input)
            {
                if (char.IsDigit(c))
                {
                    digitCount++;
                    Console.WriteLine($"Найдена цифра: {c}");
                }
            }
            Console.WriteLine($"Общее количество цифр: {digitCount}");
            var elementsBeforeSlash = input.Split('/').TakeWhile(s => s != "").ToList();
            foreach (var str in elementsBeforeSlash)
            {
                Console.WriteLine(str);
            }
            var elementsAfterSlash = input.Split('/').SkipWhile(s => s != "").Skip(1).Select(s => Swap(s)).ToList();
            foreach (var str in elementsAfterSlash)
            {
                Console.WriteLine(str);
            }
            File.WriteAllLines("text.txt", elementsAfterSlash);
            Console.ReadKey();
        }

       

    }
}
